# Rosie Resume
## Mini Resume Project With Bootstrap

[View this website on GitHub Pages](https://kescardoso.github.io/rosie-project/)

Welcome!

This is a fictitious online resume for a software developer.

Resources used:

1. [Bootstrap](https://www.bootstrapcdn.com/)
2. [Google Fonts](https://fonts.google.com/)
3. [Menu Hover Efects 1](https://cdnjs.com/)
4. [Menu Hover Effects 2](http://ianlunn.github.io/Hover/)

Thank you :)
[Kes Cardoso](www.kescardoso.com)